//
//  ProfileViewController.m
//  Development Test
//
//  Created by Development Test on 25/05/15.
//  Copyright (c) 2015 Development. All rights reserved.
//

static NSInteger ASTagProfileImage = 101;

static NSString *ASTitleFromAlbum  = @"From Album";
static NSString *ASTitleFromCamera = @"From Camera";
static NSString *ASTitleFromCancel = @"Cancel";

#import "ProfileViewController.h"

@interface ProfileViewController ()
<UIActionSheetDelegate,
UIImagePickerControllerDelegate,
UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextField *txtFirstName;
@property (weak, nonatomic) IBOutlet UITextField *txtLastName;
@property (weak, nonatomic) IBOutlet UITextField *txtDateOfBirth;

@property (weak, nonatomic) IBOutlet UIButton *btnProfileImage;
@property (weak, nonatomic) IBOutlet UIButton *btnGender;
@property (weak, nonatomic) IBOutlet UIButton *btnBirthDate;

@property (weak, nonatomic) IBOutlet UIScrollView *scrvProfile;

@property (strong, nonatomic) ZWTTextboxToolbarHandler *textboxHandler;

@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *birthDate;
@property (strong, nonatomic) NSString *gender;
@property (strong, nonatomic) NSData *imageData;

@end

@implementation ProfileViewController

@synthesize btnGender, btnProfileImage, btnBirthDate;
@synthesize txtFirstName, txtLastName, txtDateOfBirth;
@synthesize scrvProfile, textboxHandler;
@synthesize firstName, lastName, birthDate, gender, imageData;

#pragma mark - UIViewController Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self prepareViews];
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

#pragma mark - Views Methods
- (void)prepareViews
{
    [self prepareProfileView];
    [self prepareTextFields];
}

- (void)prepareProfileView
{
    btnProfileImage.layer.cornerRadius = 5.0;
    
    btnProfileImage.clipsToBounds = YES;
}

- (void)prepareTextFields
{
    NSArray *allTextFields = @[txtFirstName, txtLastName, txtDateOfBirth];
    
    for(UITextField *textField in allTextFields)
    {
        textField.leftViewMode = UITextFieldViewModeAlways;
        textField.leftView     = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
    }
    
    textboxHandler = [[ZWTTextboxToolbarHandler alloc] initWithTextboxs:allTextFields andScroll:scrvProfile];
}

#pragma mark - Enents Methods
- (IBAction)btngenderTap:(UIButton *)sender
{
    if(btnGender.isSelected)
    {
        [btnGender setImage:[UIImage imageNamed:@"switch_gender_male"] forState:UIControlStateNormal];
        
        btnGender.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        
        btnGender.selected = NO;
    }
    else
    {
        [btnGender setImage:[UIImage imageNamed:@"switch_gender_female"] forState:UIControlStateNormal];
        
        btnGender.contentHorizontalAlignment = UIControlContentHorizontalAlignmentRight;
        
        btnGender.selected = YES;
    }
}

- (IBAction)btnProfileTap:(UIButton *)sender
{
    UIActionSheet *videoActionSheet = [[UIActionSheet alloc] initWithTitle:@"Choose Picture"
                                                                  delegate:self
                                                         cancelButtonTitle:ASTitleFromCamera
                                                    destructiveButtonTitle:nil
                                                         otherButtonTitles:ASTitleFromAlbum, ASTitleFromCamera, nil];
    videoActionSheet.tag = ASTagProfileImage;
    
    [videoActionSheet showInView:self.view];
}

- (IBAction)swipeDown:(UISwipeGestureRecognizer *)sender
{
    if([self validateUserProfile])
    {
        
    }
}
#pragma mark - Helper Methods
- (BOOL)validateUserProfile
{
    firstName = [txtFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    lastName  = [txtLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    birthDate = [btnBirthDate titleForState:UIControlStateNormal];
    imageData = [NSData dataWithData:UIImagePNGRepresentation([btnProfileImage imageForState:UIControlStateNormal])];
    
    if (firstName.length == 0)
    {
        NSLog(@"Please Enter FirstName.");
        
        return NO;
    }
    else if (lastName.length == 0)
    {
        NSLog(@"Please Enter LastName.");
        
        return NO;
    }
    else if (birthDate.length == 0)
    {
        NSLog(@"Please Enter Birthdate.");
        
        return NO;
    }
    else if (imageData.length == 0)
    {
        NSLog(@"Please Select Image");
        
        return NO;
    }
    else if (gender.length == 0)
    {
        NSLog(@"Please Select Gender");
        
        return NO;
    }
    
    return YES;
}

#pragma mark - UIActionSheetDelegate Methods
- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    NSString *buttonTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
    
    if(actionSheet.tag == ASTagProfileImage && ![buttonTitle isEqualToString:ASTitleFromCancel])
    {
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        
        controller.delegate      = self;
        controller.allowsEditing = YES;
        
        if([buttonTitle isEqualToString:ASTitleFromCamera])
        {
            controller.sourceType   = UIImagePickerControllerSourceTypeCamera;
        }
        else if ([buttonTitle isEqualToString:ASTitleFromAlbum])
        {
            controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary ;
        }
        
        controller.navigationBar.tintColor = [UIColor blackColor];
        
        [self presentViewController:controller animated:YES completion:nil];
    }
}

#pragma mark - UIImagePickerControllerDelegate Methods
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info;
{
    [btnProfileImage setImage:[info objectForKey:UIImagePickerControllerEditedImage] forState:UIControlStateNormal];
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end